//
//  ViewController.swift
//
//  Created by Lab PUM on 30.09.2018.
//  Copyright © 2018 MM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var face: FaceView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        face.setNeedsDisplay()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

